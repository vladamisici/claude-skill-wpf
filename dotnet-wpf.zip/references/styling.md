# WPF Styling, Templates, and Theming

Contents: [Resource organization](#resource-organization) · [Styles](#styles) ·
[ControlTemplate vs DataTemplate](#controltemplate-vs-datatemplate) · [Triggers](#triggers) ·
[Theming](#theming--runtime-theme-switching) · [Gotchas](#gotchas)

---

## Resource organization

One dictionary per concern, merged in App.xaml — order matters (later wins; styles reference earlier dictionaries):

```xml
<Application.Resources>
    <ResourceDictionary>
        <ResourceDictionary.MergedDictionaries>
            <ResourceDictionary Source="Resources/Colors.xaml"/>     <!-- Color + Brush -->
            <ResourceDictionary Source="Resources/Typography.xaml"/> <!-- FontSizes, TextBlock styles -->
            <ResourceDictionary Source="Resources/Controls.xaml"/>   <!-- per-control styles -->
        </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
</Application.Resources>
```

Layer colors → brushes → styles so theming swaps only the bottom layer:

```xml
<!-- Colors.xaml -->
<Color x:Key="AccentColor">#0078D4</Color>
<SolidColorBrush x:Key="AccentBrush" Color="{StaticResource AccentColor}"/>
```

Naming: semantic (`AccentBrush`, `SurfaceBrush`, `DangerBrush`), never literal (`BlueBrush`). Brushes declared in XAML resources are frozen automatically when possible — declare shared brushes there, not in code.

`x:Shared="False"` on a resource yields a new instance per lookup — needed when a resource is a UI element or mutated per use; rare otherwise.

## Styles

```xml
<!-- Implicit: applies to every Button in scope that doesn't set Style -->
<Style TargetType="Button">
    <Setter Property="Padding" Value="12,6"/>
    <Setter Property="Background" Value="{StaticResource AccentBrush}"/>
</Style>

<!-- Keyed variant building on the implicit one -->
<Style x:Key="DangerButton" TargetType="Button"
       BasedOn="{StaticResource {x:Type Button}}">
    <Setter Property="Background" Value="{StaticResource DangerBrush}"/>
</Style>
```

- Implicit styles **do not flow into templates of other controls** by default, and implicit `ToolTip`/`ContextMenu`/`Window` styles each have scoping quirks — keyed styles are more predictable for those.
- `BasedOn` is single inheritance; a setter in the derived style fully overrides the base setter for that property.
- Implicit styles defined in a `UserControl`'s resources scope to that control only — app-wide styles live in App.xaml merges.
- A locally set property (`<Button Background="Red">`) always beats style setters (dependency property value precedence). Triggers in the *style* lose to local values too — a top reason "my trigger doesn't work."

## ControlTemplate vs DataTemplate

- **ControlTemplate** = how a *control* is drawn (replace Button's chrome). Bind to the control's own properties with `{TemplateBinding ...}`.
- **DataTemplate** = how a *data object* is presented (Customer → row layout). Bind to the data item with plain `{Binding ...}`.

When restyling a control's visuals, retemplate rather than fighting the default template:

```xml
<Style TargetType="Button" x:Key="FlatButton">
    <Setter Property="Background" Value="{StaticResource AccentBrush}"/>
    <Setter Property="Foreground" Value="White"/>
    <Setter Property="Template">
        <Setter.Value>
            <ControlTemplate TargetType="Button">
                <Border x:Name="Root" Background="{TemplateBinding Background}"
                        CornerRadius="4" Padding="{TemplateBinding Padding}">
                    <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <ControlTemplate.Triggers>
                    <Trigger Property="IsMouseOver" Value="True">
                        <Setter TargetName="Root" Property="Background"
                                Value="{StaticResource AccentHoverBrush}"/>
                    </Trigger>
                    <Trigger Property="IsEnabled" Value="False">
                        <Setter TargetName="Root" Property="Opacity" Value="0.5"/>
                    </Trigger>
                </ControlTemplate.Triggers>
            </ControlTemplate>
        </Setter.Value>
    </Setter>
</Style>
```

**Retemplating erases all built-in visuals and states.** A custom template must re-handle: `IsMouseOver`, `IsPressed`, `IsEnabled`, keyboard focus visuals (`IsKeyboardFocused` or `FocusVisualStyle`), and for inputs, validation visuals. Forgetting focus visuals is an accessibility regression — always include at least an `IsKeyboardFocused` trigger or keep `FocusVisualStyle`.

To start from the real default template instead of guessing: VS → right-click control in designer → Edit Template → Edit a Copy. (Default templates are far more complex than hand-written ones for a reason.)

Typed DataTemplates (no key) auto-apply by item type — the core of VM-first navigation and heterogeneous lists:

```xml
<DataTemplate DataType="{x:Type m:ImageItem}"> ... </DataTemplate>
<DataTemplate DataType="{x:Type m:TextItem}">  ... </DataTemplate>
```

For selection logic beyond type matching, implement `DataTemplateSelector` and set `ItemTemplateSelector` — but prefer type-based templates or `DataTrigger`s when they suffice.

## Triggers

| Need | Use |
|---|---|
| React to a property of the control itself (hover, pressed, enabled) | `Trigger` in ControlTemplate/Style |
| React to bound data (status == Error → red) | `DataTrigger` with `{Binding Status}` |
| Multiple conditions ANDed | `MultiTrigger` / `MultiDataTrigger` |
| React to an event with animation | `EventTrigger` + `Storyboard` |

```xml
<Style TargetType="TextBlock" x:Key="StatusText">
    <Style.Triggers>
        <DataTrigger Binding="{Binding Status}" Value="Error">
            <Setter Property="Foreground" Value="{StaticResource DangerBrush}"/>
        </DataTrigger>
    </Style.Triggers>
</Style>
```

DataTriggers often beat converters: declarative, visible in the XAML where the effect happens, no extra class. Use a converter when the *output value* must be computed; use a trigger when it's a discrete state→appearance mapping.

Remember precedence: a locally set `Foreground` on the element defeats the trigger.

## Theming / runtime theme switching

Pattern: theme = a ResourceDictionary of brushes with **fixed keys**; consumers reference them via `DynamicResource`; switching = swapping the merged dictionary.

```csharp
public static void ApplyTheme(string name) // "Dark" / "Light"
{
    var dicts = Application.Current.Resources.MergedDictionaries;
    var old = dicts.FirstOrDefault(d => d.Source?.OriginalString.Contains("/Themes/") == true);
    if (old is not null) dicts.Remove(old);
    dicts.Add(new ResourceDictionary { Source = new Uri($"Resources/Themes/{name}.xaml", UriKind.Relative) });
}
```

- Only the **theme-variable** brushes need `DynamicResource` at point of use; everything static stays `StaticResource`.
- .NET 9 adds experimental Fluent theming (`ThemeMode`) and Windows 11 styling — check current docs before recommending; for production theming today, MahApps.Metro or MaterialDesignInXAML are the proven routes, or hand-rolled dictionaries as above.
- Respect OS dark mode: read `AppsUseLightTheme` from registry (`HKCU\...\Themes\Personalize`) and listen to `SystemEvents.UserPreferenceChanged`.

## Gotchas

- **Pack URIs** for resources in other assemblies: `pack://application:,,,/MyApp.Themes;component/Dark.xaml`. Build action for dictionaries: `Page` (default for .xaml) — `Resource`/`Content` cause runtime `IOException`/missing-style symptoms.
- A `ResourceDictionary` with code-behind (`x:Class`) or merged repeatedly in every view multiplies parse cost — merge shared dictionaries once at App level; per-view merging of the same file re-parses per view on .NET Framework (modern .NET caches by URI, but App-level is still cleanest).
- `StaticResource` is resolved at parse time top-to-bottom: forward references fail. `DynamicResource` tolerates them at the price of a live expression.
- Styling `DataGrid` rows: `RowStyle`/`CellStyle`, and `AlternationCount` + `ItemsControl.AlternationIndex` triggers for striping — don't bind row background to item index.
- Fonts: ship custom fonts as embedded resources, reference `"./Resources/#Font Name"`; `FontFamily` with a wrong family name silently falls back without error.
