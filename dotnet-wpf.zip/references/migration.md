# WPF Migration: .NET Framework 4.x → Modern .NET

Contents: [Decision](#should-you-migrate-at-all) · [Mechanics](#mechanics) ·
[What breaks](#what-breaks-and-the-replacements) · [Third-party controls](#third-party-controls) ·
[Validation checklist](#post-migration-validation)

---

## Should you migrate at all?

Reasons to migrate: yearly .NET performance gains, modern C#, NuGet ecosystem (many packages dropped netfx targets), self-contained deployment, active support. Reasons to wait: heavy dependence on AppDomains/Remoting/WCF-server/WF, a third-party control vendor without a modern build, or an app in pure maintenance mode (Framework 4.8.x ships with Windows and is serviced indefinitely).

Target the **current LTS** (check what's latest; e.g. `net8.0-windows` as of this writing) unless the user needs newer features. Never plain `netX.0` — WPF requires the `-windows` TFM and `<UseWPF>true</UseWPF>`.

## Mechanics

Recommended order:

1. **Inventory dependencies first**: `dotnet list package` won't work yet on old csproj — read packages.config / csproj manually, and check each package supports `net6.0+` or `netstandard2.0`. This step kills more migrations than code does.
2. **Convert to SDK-style csproj while still targeting net48.** Either with the Upgrade Assistant (`dotnet tool install -g upgrade-assistant`, then `upgrade-assistant upgrade <proj>`) or by hand:
   ```xml
   <Project Sdk="Microsoft.NET.Sdk">
     <PropertyGroup>
       <OutputType>WinExe</OutputType>
       <TargetFramework>net48</TargetFramework>
       <UseWPF>true</UseWPF>
       <!-- if any WinForms interop (WindowsFormsHost, FolderBrowserDialog): -->
       <UseWindowsForms>true</UseWindowsForms>
     </PropertyGroup>
   </Project>
   ```
   SDK-style globs all `.cs`/`.xaml` automatically — delete the old explicit `<Compile>`/`<Page>` items; watch for files that were in the folder but deliberately excluded (they're now included!).
   Migrate packages.config → `<PackageReference>` (VS has a right-click converter).
3. **Build + run green on net48 SDK-style.** Commit.
4. **Flip the TFM** to `net8.0-windows`, fix what breaks (next section).
5. `AssemblyInfo.cs` attributes now collide with SDK auto-generation — delete duplicates or set `<GenerateAssemblyInfo>false</GenerateAssemblyInfo>`.
6. App.config: most of it (binding redirects!) becomes unnecessary; `appSettings` still works via `System.Configuration.ConfigurationManager` (NuGet package now), but prefer migrating to `Microsoft.Extensions.Configuration` + appsettings.json.

## What breaks, and the replacements

| Gone / changed on modern .NET | Replacement |
|---|---|
| **WCF server-side** (`ServiceHost`) | CoreWCF (community/Microsoft-supported) or migrate transport to gRPC / ASP.NET Core Web API |
| **WCF client** | `System.ServiceModel.*` NuGet packages (client-only) work; or regenerate with `dotnet-svcutil` |
| **Workflow Foundation** | CoreWF (community) or redesign |
| **AppDomains** (isolation/unload) | `AssemblyLoadContext` for unloading; processes for isolation |
| **.NET Remoting** | Anything else: gRPC, named pipes (`StreamJsonRpc`), REST |
| **`System.Drawing` on non-Windows** | Irrelevant for WPF (Windows-only anyway) — `System.Drawing.Common` works on Windows |
| **XBAPs, partial-trust** | No equivalent; rearchitect |
| Many `System.Configuration` patterns, `SectionGroup`s | `Microsoft.Extensions.Configuration` |
| `WebBrowser` control (Trident/IE) | Still exists but is legacy IE; use **WebView2** (`Microsoft.Web.WebView2`) |
| Global GAC assumptions, registry-free COM quirks | Self-contained or framework-dependent deployment; COM still works on Windows |
| `BinaryFormatter` serialization | Removed/blocked in newer .NET — System.Text.Json, protobuf, MessagePack |

Bridge package: `Microsoft.Windows.Compatibility` restores a large slab of Windows-only API surface (registry, directory services, ODBC...) in one reference — good for getting green fast; trim it later.

Behavioral diffs worth knowing:
- New default rendering/text stack differences are minimal, but per-monitor DPI handling is opt-in via app.manifest on both runtimes — carry the manifest over.
- `Application.DoEvents` doesn't exist (it was WinForms anyway); code "pumping" the dispatcher with nested frames should be redesigned around async.
- Culture-sensitive string behavior changed (ICU vs NLS) on .NET 5+ — string comparisons/sorting may order differently; opt out with `InvariantGlobalization` only if you understand the cost, better: audit `string.Compare`/sorting for explicit `StringComparison`.
- `Encoding.GetEncoding(1252)` etc. requires `System.Text.Encoding.CodePages` + `Encoding.RegisterProvider`.

## Third-party controls

Check vendor support **before** starting: DevExpress, Telerik, Syncfusion, Infragistics, ComponentOne all ship modern-.NET builds for recent versions — but a project pinned to a 2016-era license may face a paid upgrade. Open-source stalwarts: MahApps.Metro, MaterialDesignInXAML, Extended WPF Toolkit (partially maintained — audit), HandyControl. `System.Windows.Interactivity` → `Microsoft.Xaml.Behaviors.Wpf` (namespace swap: `xmlns:i="http://schemas.microsoft.com/xaml/behaviors"`).

## Post-migration validation

- [ ] App starts framework-dependent **and** (if used) self-contained / single-file — single-file publish changes `Assembly.Location` (empty!) → fix path logic to `AppContext.BaseDirectory`
- [ ] All windows open; styles/themes intact (missing implicit styles indicate resource dictionary build-action regressions)
- [ ] Settings/config load (binding-redirect-era assumptions removed)
- [ ] Serialization round-trips (BinaryFormatter remnants found and replaced)
- [ ] COM interop / P/Invoke paths exercised on target bitness (`<PlatformTarget>`; AnyCPU now defaults to 64-bit-preferred)
- [ ] Sorting/comparison behavior spot-checked (ICU change)
- [ ] Installer/deployment updated (no .NET Framework prerequisite; instead runtime-included or windowsdesktop runtime check)
