# WPF Anti-Patterns, Leaks, and Performance

Contents: [Memory leaks](#memory-leaks-ranked-by-how-often-they-actually-happen) ·
[Threading bugs](#threading-bugs) · [Binding mistakes](#binding-mistakes) ·
[Performance](#performance) · [Architecture smells](#architecture-smells)

---

## Memory leaks (ranked by how often they actually happen)

### 1. Binding to a CLR property of an object that doesn't implement INPC
WPF tracks changes on non-INPC sources via `PropertyDescriptor.AddValueChanged`, which holds a **global strong reference** to the source object. If the bound object is long-lived and views come and go, every view leaks.

Fix any of: implement `INotifyPropertyChanged` on anything bound; or mark the binding `Mode=OneTime`; or make the bound member a `DependencyProperty`. Rule for generated code: **every bound source type implements INPC, period** (MVVM Toolkit makes this free).

### 2. Events: long-lived publisher, short-lived subscriber
```csharp
// LEAK: service is a singleton; this VM can never be collected
_settingsService.SettingsChanged += OnSettingsChanged;
```
Fixes, in order of preference: unsubscribe deterministically (`IDisposable` VM disposed on navigation/window close); `WeakReferenceMessenger` instead of raw events; `WeakEventManager<TSource, TArgs>.AddHandler` when you can't change either side.

### 3. `DispatcherTimer` keeps its owner alive
The Dispatcher holds the timer; the timer holds the `Tick` handler; the handler holds the VM/window. Always `Stop()` the timer in `Closed`/dispose. Same for `System.Timers.Timer`/`Threading.Timer` plus the bonus problem that their callbacks arrive off-thread.

### 4. Static / App-level resources holding view references
Caching a `Window`/control in a static field, an App-resource `ObservableCollection` bound by many views (the views unhook, but `CollectionChanged` subscriptions from custom code don't), or `x:Shared="False"` misuse.

### 5. Unfrozen Freezables created per-render
Not a leak but allocation churn: `Brush`/`Geometry`/`Transform` created in code and used by UI should be `.Freeze()`d — frozen freezables drop their change infrastructure, become thread-safe, and render faster.

**Diagnosis**: take two gcdumps (VS Diagnostic Tools or `dotnet-gcdump`) before/after opening-closing the suspect window; the window type's instance count should return to baseline. Search retention paths for `PropertyDescriptor`, `EventHandler`, `DispatcherTimer`.

---

## Threading bugs

### `async void`
Only valid for event handlers, and even then wrap in try/catch — an exception in `async void` crashes the process (or vanishes, on some runtimes). Everywhere else: `async Task`. Watch for it hiding in `OnStartup`, `Loaded` handlers, and ICommand implementations that aren't toolkit `AsyncRelayCommand`.

```csharp
private async void Window_Loaded(object sender, RoutedEventArgs e)
{
    try { await ViewModel.InitializeAsync(); }
    catch (Exception ex) { /* log, show error state */ }
}
```

### `ConfigureAwait(false)` in ViewModels
Correct in libraries; wrong in VMs. After it, you're on a thread-pool thread and the next `Items.Add(...)` throws (collections) or works-by-luck (scalars are marshaled, which *hides* the bug until a collection is touched). VM code: no `ConfigureAwait` at all.

### Blocking on async: `.Result`, `.Wait()`, `GetAwaiter().GetResult()`
On the UI thread this deadlocks classically: the continuation needs the UI thread, which is blocked waiting for the continuation. There is no safe sync-over-async on a `SynchronizationContext` thread. Make the call chain async; for constructors, use an async factory or fire an `InitializeAsync` from `Loaded`/an async command.

### Cross-thread collection mutation
`ObservableCollection<T>` from a background thread → `NotSupportedException` ("This type of CollectionView does not support changes..."). Either marshal back before mutating (preferred — just don't leave the UI context) or:
```csharp
private readonly object _lock = new();
// UI thread, once:
BindingOperations.EnableCollectionSynchronization(Items, _lock);
// any thread, hold the lock while mutating:
lock (_lock) Items.Add(item);
```

### Dispatcher misuse
- `Dispatcher.Invoke` from the UI thread itself with a pending background `Invoke` is a deadlock vector; prefer `InvokeAsync`.
- `Application.Current` is null during shutdown and in unit tests — guard or inject a dispatcher abstraction.
- Don't sprinkle `Dispatcher.Invoke` through VMs "just in case" — it means the threading model is unclear. Fix the model.

---

## Binding mistakes

### Silent failures treated as "WPF being weird"
A typo'd path costs nothing visible at runtime. During development, make failures loud:

```csharp
#if DEBUG
PresentationTraceSources.Refresh();
PresentationTraceSources.DataBindingSource.Listeners.Add(new ThrowingTraceListener());
PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Error;
#endif

private sealed class ThrowingTraceListener : TraceListener
{
    public override void Write(string? message) { }
    public override void WriteLine(string? message)
        => throw new InvalidOperationException("Binding failure: " + message);
}
```
(Or log instead of throw; the point is non-silence.)

### Raising INPC with string literals
`OnPropertyChanged("Naem")` compiles and never works. Minimum: `nameof()`. Better: source generators (`[ObservableProperty]`) so the question can't arise.

### Replacing the collection but not raising change
`Customers = new ObservableCollection<…>(…)` on a plain auto-property — the binding still points at the old collection. If you replace, the property itself must raise `PropertyChanged`. If you mutate, the property can be `get`-only. Pick one convention per VM.

### Binding to fields, methods, or non-public properties
Bindings see public instance **properties** only. `public string Name;` (a field) silently binds to nothing.

### DataContext confusion inside DataTemplates/ContextMenus/Popups
Inside an `ItemTemplate`, `DataContext` is the **item**, not the page VM — reach out with `RelativeSource AncestorType`. `ContextMenu` and `Popup` are **not in the visual tree**: `ElementName` and `AncestorType` fail there; use `PlacementTarget`:
```xml
<ContextMenu DataContext="{Binding PlacementTarget.DataContext,
                           RelativeSource={RelativeSource Self}}">
    <MenuItem Header="Delete" Command="{Binding DeleteCommand}"/>
</ContextMenu>
```

### Converter overuse
Chains of converters encoding business rules belong in the VM as computed properties (testable, debuggable). Converters: formatting and view-mechanical transforms only.

---

## Performance

### Virtualization that isn't happening
`ListBox`/`ListView`/`DataGrid` virtualize **by default**, but it silently breaks when:
- the list is inside a `StackPanel` or a `ScrollViewer` → infinite measure height → all items realized. Host lists in `Grid` rows (`Height="*"`) or `DockPanel`.
- `ScrollViewer.CanContentScroll="False"` (pixel scrolling pre-4.5) → off. On 4.5+ use `VirtualizingPanel.ScrollUnit="Pixel"` to get smooth scrolling *and* virtualization.
- the `ItemsPanel` was replaced with a non-virtualizing panel (`WrapPanel`, `StackPanel`).
- grouping is enabled without `VirtualizingPanel.IsVirtualizingWhenGrouping="True"`.

Add recycling for big lists: `VirtualizingPanel.VirtualizationMode="Recycling"` — but then item containers are reused, so never store per-item state on the container.

`ItemsControl` itself does **not** virtualize by default — for large data use ListBox or set a virtualizing panel + template explicitly.

### StaticResource vs DynamicResource
`DynamicResource` keeps a live lookup expression per use — flexible (theming) but heavier. Default to `StaticResource`; use `DynamicResource` only for resources that genuinely change at runtime (theme switches) or are defined *after* the point of use.

### Per-item visual weight
The biggest DataGrid/ListBox perf lever is the item template. Avoid nested `Grid`s with many auto-measured rows, per-item `DropShadowEffect` (software-rendered!), and per-item converters doing real work. Measure with the Visual Studio "Application Timeline" / PerfView before optimizing.

### Startup
- Defer-load tabs/views (`ContentControl` + lazy VM creation) rather than building the whole visual tree up front.
- `BitmapImage`: set `DecodePixelWidth` to the display size — decoding full-resolution photos for 64px thumbnails is a classic memory/CPU sink. Set `CacheOption=OnLoad` if the source stream closes.
- ReadyToRun / NativeAOT note: WPF does **not** support NativeAOT; ReadyToRun publishing works and helps cold start.

### Binding cost
There are no compiled bindings in WPF; per-binding cost is reflection-based. For 10⁵+ bindings: prefer `OneTime` where possible, trim `DataTrigger` count in item templates, consider lighter-weight rendering (`DrawingVisual`/`OnRender`) for dense custom visuals like charts.

---

## Architecture smells

| Smell | Why it bites | Replace with |
|---|---|---|
| Business logic in code-behind | Untestable, couples logic to visual tree lifetime | VM commands + services; code-behind = view-mechanical only (focus, animations, drag visuals) |
| God ViewModel (2k+ lines) | Change amplification, untestable | One VM per view region; child VMs composed via properties |
| `MessageBox.Show` / `new SomeWindow().ShowDialog()` in VM | UI-thread coupling, untestable | `IDialogService` (see patterns.md) |
| Manual `INotifyPropertyChanged` boilerplate | Typos, missed notifications | `CommunityToolkit.Mvvm` source generators |
| VM referencing controls (`TextBox`, `Window`) | Inverts MVVM; breaks tests | Bindings, attached behaviors, or services |
| Singleton VMs holding per-session state forever | Stale data, hidden coupling | Scoped/transient VMs; explicit lifetime owned by navigation |
| `Thread.Sleep` / sync I/O in handlers | Frozen UI ("not responding") | async/await throughout |
| Catch-all `DispatcherUnhandledException` that swallows | Hides corruption, app limps on | Log + decide: recoverable (handled=true + user message) vs not (let it crash, crash dump) |
| Hardcoded colors/margins copy-pasted across views | Inconsistent theming | Resource dictionaries; see styling.md |
