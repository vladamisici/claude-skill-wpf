# WPF Patterns Reference

Contents: [Validation](#validation) · [CollectionViewSource](#sorting-filtering-grouping-collectionviewsource) ·
[Event → Command](#event--command-microsoftxamlbehaviorswpf) · [Dialogs from ViewModels](#dialogs-from-viewmodels) ·
[Navigation](#navigation-between-views) · [Messenger](#cross-viewmodel-communication-messenger) ·
[Converters](#value-converters) · [Attached behaviors](#attached-behaviors) · [Design-time data](#design-time-data) ·
[Binding modes & triggers](#binding-modes--updatesourcetrigger-cheat-sheet)

---

## Validation

`[NotifyDataErrorInfo]` only works on classes deriving from **`ObservableValidator`** (not `ObservableObject`):

```csharp
public partial class CustomerEditViewModel : ObservableValidator
{
    [ObservableProperty]
    [NotifyDataErrorInfo]
    [Required(ErrorMessage = "Name is required")]
    [MinLength(2, ErrorMessage = "At least 2 characters")]
    public partial string Name { get; set; } = string.Empty;

    [RelayCommand]
    private void Save()
    {
        ValidateAllProperties();        // validate non-edited fields too
        if (HasErrors) return;
        // persist...
    }
}
```

XAML side — `ValidatesOnNotifyDataErrors` is `true` by default, but you usually want an explicit error display instead of the default red border:

```xml
<TextBox Text="{Binding Name, UpdateSourceTrigger=PropertyChanged}">
    <Validation.ErrorTemplate>
        <ControlTemplate>
            <StackPanel>
                <AdornedElementPlaceholder/>
                <TextBlock Foreground="Red" FontSize="11"
                           Text="{Binding [0].ErrorContent}"/>
            </StackPanel>
        </ControlTemplate>
    </Validation.ErrorTemplate>
</TextBox>
```

The error template is rendered in the **adorner layer** — it doesn't take layout space. Reserve room below the TextBox (margin) or the message overlaps the next control.

Disable Save while invalid: `HasErrors` is observable — `ErrorsChanged` fires; in the VM call `SaveCommand.NotifyCanExecuteChanged()` from an `ErrorsChanged` handler, with `CanSave() => !HasErrors`.

For cross-field rules, use a `[CustomValidation(typeof(MyVm), nameof(ValidateDates))]` static method or override with manual `SetErrors`.

## Sorting, filtering, grouping: CollectionViewSource

Never rebuild collections to filter/sort — bind through a view:

```csharp
public partial class CustomersViewModel : ObservableObject
{
    public ObservableCollection<Customer> Customers { get; } = [];
    public ICollectionView CustomersView { get; }

    [ObservableProperty]
    public partial string SearchText { get; set; } = string.Empty;

    public CustomersViewModel()
    {
        CustomersView = CollectionViewSource.GetDefaultView(Customers);
        CustomersView.Filter = o => string.IsNullOrEmpty(SearchText)
            || ((Customer)o).Name.Contains(SearchText, StringComparison.OrdinalIgnoreCase);
        CustomersView.SortDescriptions.Add(
            new SortDescription(nameof(Customer.Name), ListSortDirection.Ascending));
    }

    partial void OnSearchTextChanged(string value) => CustomersView.Refresh();
}
```

```xml
<TextBox Text="{Binding SearchText, UpdateSourceTrigger=PropertyChanged}"/>
<DataGrid ItemsSource="{Binding CustomersView}" .../>
```

Caveats:
- `GetDefaultView` returns the view *every* binding to that collection shares. For independent views (two grids, different filters) create a `new CollectionViewSource { Source = Customers }.View`.
- `Filter` runs per item on `Refresh()` — fine to ~10⁴ items; beyond that filter in the service layer.
- Grouping (`GroupDescriptions` + `GroupStyle`) **disables UI virtualization** before .NET Framework 4.5; on modern WPF set `VirtualizingPanel.IsVirtualizingWhenGrouping="True"`.
- Live re-sorting on property change: cast to `ICollectionViewLiveShaping`, add to `LiveSortingProperties`, set `IsLiveSorting = true`.

## Event → Command (Microsoft.Xaml.Behaviors.Wpf)

For events with no `Command` property (e.g. `SelectionChanged`, `Loaded`, `MouseDoubleClick`). NuGet: `Microsoft.Xaml.Behaviors.Wpf` (the old `System.Windows.Interactivity` is dead — if migrating, swap the namespace).

```xml
xmlns:b="http://schemas.microsoft.com/xaml/behaviors"

<ListBox ItemsSource="{Binding Items}">
    <b:Interaction.Triggers>
        <b:EventTrigger EventName="MouseDoubleClick">
            <b:InvokeCommandAction Command="{Binding OpenItemCommand}"
                                   CommandParameter="{Binding SelectedItem,
                                       RelativeSource={RelativeSource AncestorType=ListBox}}"/>
        </b:EventTrigger>
    </b:Interaction.Triggers>
</ListBox>
```

Prefer plain `Command`/`InputBindings` when available:

```xml
<DataGrid.InputBindings>
    <KeyBinding Key="Delete" Command="{Binding DeleteCommand}"/>
    <MouseBinding MouseAction="LeftDoubleClick" Command="{Binding OpenItemCommand}"/>
</DataGrid.InputBindings>
```

Don't use behaviors to replace `SelectedItem="{Binding ...}"` — direct binding is simpler and two-way by default on `Selector`.

## Dialogs from ViewModels

Never construct `Window`s or call `MessageBox.Show` inside a ViewModel (untestable). Inject a dialog service:

```csharp
public interface IDialogService
{
    bool Confirm(string message, string title);
    string? PickFile(string filter);
    Task<TResult?> ShowDialogAsync<TViewModel, TResult>(TViewModel vm)
        where TViewModel : IDialogViewModel<TResult>;
}

// WPF implementation lives in the composition root / a UI-layer project
public sealed class DialogService(IServiceProvider sp) : IDialogService
{
    public bool Confirm(string message, string title) =>
        MessageBox.Show(Application.Current.MainWindow, message, title,
            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

    public string? PickFile(string filter)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog { Filter = filter };
        return dlg.ShowDialog() == true ? dlg.FileName : null;
    }
    // ShowDialogAsync: resolve the View mapped to TViewModel, set DataContext,
    // ShowDialog(), return vm.Result.
}
```

In tests, substitute `IDialogService` and assert it was called.

## Navigation between views

Smallest viable pattern — a current-VM property plus DataTemplates:

```csharp
public partial class ShellViewModel : ObservableObject
{
    private readonly IServiceProvider _sp;
    public ShellViewModel(IServiceProvider sp) { _sp = sp; CurrentPage = sp.GetRequiredService<HomeViewModel>(); }

    [ObservableProperty]
    public partial ObservableObject CurrentPage { get; set; }

    [RelayCommand]
    private void GoToCustomers() => CurrentPage = _sp.GetRequiredService<CustomersViewModel>();
}
```

```xml
<Window.Resources>
    <DataTemplate DataType="{x:Type vm:HomeViewModel}">      <views:HomeView/>      </DataTemplate>
    <DataTemplate DataType="{x:Type vm:CustomersViewModel}"> <views:CustomersView/> </DataTemplate>
</Window.Resources>
<ContentControl Content="{Binding CurrentPage}"/>
```

Typed `DataTemplate`s set the view's `DataContext` automatically — the views here must be `UserControl`s with parameterless constructors (no DataContext assignment in *their* code-behind, it would override the template's). Add an `INavigationService` abstraction only when navigation logic (history, guards, parameters) actually appears.

If old VMs hold event subscriptions or timers, dispose them on navigation: implement `IDisposable` and dispose the previous `CurrentPage` when swapping.

## Cross-ViewModel communication (Messenger)

```csharp
// Sender
WeakReferenceMessenger.Default.Send(new CustomerSavedMessage(customer));

// Receiver (e.g. in ctor)
WeakReferenceMessenger.Default.Register<CustomerSavedMessage>(this,
    (recipient, msg) => ((DashboardViewModel)recipient).OnCustomerSaved(msg.Value));

public sealed class CustomerSavedMessage(Customer value) : ValueChangedMessage<Customer>(value);
```

`WeakReferenceMessenger` doesn't keep recipients alive (no leak), but explicit `Unregister` in teardown is still cleaner. Use messages for *events between peers*; for parent→child data flow, plain constructor parameters or properties beat messaging.

## Value converters

```csharp
public sealed class InverseBoolConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c) => value is false;
    public object ConvertBack(object value, Type t, object p, CultureInfo c) => value is false;
}
```

- `BooleanToVisibilityConverter` is built into WPF — declare `<BooleanToVisibilityConverter x:Key="BoolToVis"/>` and use it; don't reimplement.
- `ConvertBack` for one-way-only converters: `throw new NotSupportedException()` (it's by design, not unfinished — `NotImplementedException` signals the wrong thing).
- Converters are resolved as resources; declare once in App.xaml-merged dictionaries, not per view.
- Returning `Binding.DoNothing` skips the update; `DependencyProperty.UnsetValue` triggers `FallbackValue`.
- Before writing a converter, consider a `DataTrigger` (declarative, no C#) or a computed read-only VM property (testable). Converters are best for genuinely view-level, reusable transforms (formatting, visibility, inversion).
- `MultiBinding` + `IMultiValueConverter` for values derived from several bindings; remember `values` may contain `DependencyProperty.UnsetValue` during initialization — guard for it.

## Attached behaviors

For reusable view-side functionality without subclassing controls:

```csharp
public static class ScrollToEnd
{
    public static readonly DependencyProperty AutoScrollProperty =
        DependencyProperty.RegisterAttached("AutoScroll", typeof(bool), typeof(ScrollToEnd),
            new PropertyMetadata(false, OnChanged));

    public static void SetAutoScroll(DependencyObject d, bool v) => d.SetValue(AutoScrollProperty, v);
    public static bool GetAutoScroll(DependencyObject d) => (bool)d.GetValue(AutoScrollProperty);

    private static void OnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is TextBox tb)
        {
            if ((bool)e.NewValue) tb.TextChanged += Handler;
            else tb.TextChanged -= Handler;
        }
    }
    private static void Handler(object s, TextChangedEventArgs e) => ((TextBox)s).ScrollToEnd();
}
```

```xml
<TextBox local:ScrollToEnd.AutoScroll="True"/>
```

Always unsubscribe in the `false` branch — attached behaviors that only ever subscribe leak handlers when the property is toggled or restyled.

## Design-time data

```xml
mc:Ignorable="d"
d:DataContext="{d:DesignInstance Type=vm:CustomersViewModel, IsDesignTimeCreatable=False}"
```

- `IsDesignTimeCreatable=False` (default) gives IntelliSense/typed binding checks without instantiating the VM — safe even when the VM has DI constructor parameters.
- `IsDesignTimeCreatable=True` requires a public parameterless constructor and actually runs your code in the designer — only for VMs explicitly built with a design-time mode.
- `d:` attributes are stripped at compile time via `mc:Ignorable="d"`; they never affect runtime.
- Quick literals for designer preview: `d:Text="Sample name"`, `d:ItemsSource="{d:SampleData ItemCount=5}"` (VS 2022).

## Binding modes & UpdateSourceTrigger cheat sheet

| Scenario | Binding |
|---|---|
| Display-only text that can change | `{Binding Name}` (OneWay is default for TextBlock.Text) |
| Display-only, never changes after load | `{Binding CreatedAt, Mode=OneTime}` — cheapest |
| Editable text, validate/react as user types | `{Binding Name, UpdateSourceTrigger=PropertyChanged}` |
| Editable text, commit on focus loss (default) | `{Binding Name}` on TextBox (TwoWay + LostFocus are defaults) |
| Selection in list/grid | `{Binding SelectedCustomer}` — `Selector.SelectedItem` defaults to TwoWay |
| Capture control state into VM without reading it | `Mode=OneWayToSource` |
| Bind to another control | `{Binding ElementName=slider, Path=Value}` |
| Bind inside ControlTemplate to templated parent | `{TemplateBinding Background}` (OneWay; use `{Binding RelativeSource={RelativeSource TemplatedParent}}` if TwoWay needed) |
| Escape a DataTemplate to reach outer VM | `{Binding DataContext.OuterCommand, RelativeSource={RelativeSource AncestorType=Window}}` |

`StringFormat` lives on the binding (`{Binding Price, StringFormat={}{0:C}}`); it implies a one-way converter and respects the thread UI culture only if `FrameworkElement.LanguageProperty` is overridden — for correct currency/date formatting app-wide:

```csharp
FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
    new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));
```
