---
name: dotnet-wpf
description: "Build, debug, and modernize WPF applications in C# on .NET or .NET Framework. Use this skill whenever the task involves WPF, XAML for Windows desktop, MVVM, data binding, DataGrid/ListBox/ItemsControl work, styles/templates/triggers, Dispatcher or UI threading issues, value converters, INotifyPropertyChanged, the CommunityToolkit.Mvvm package, or migrating a desktop app from .NET Framework to modern .NET — even if the user doesn't say 'WPF' but shows XAML with the schemas.microsoft.com/winfx namespace. Do NOT use for WinForms, UWP, WinUI 3, MAUI, or Avalonia (similar XAML, different rules)."
---

# WPF (.NET / C#)

> Compatibility: Windows-only output. Requires a WPF project (net48 or net6.0-windows+ with `<UseWPF>true</UseWPF>`).

## Scope check (do this first)

1. **Confirm it's actually WPF.** Avalonia, WinUI 3, UWP, and MAUI all look like WPF but differ in
   binding syntax, namespaces, and lifecycle. Telltale WPF signs: `xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"`, `Window`/`UserControl` code-behind with `InitializeComponent()`, `App.xaml` with `StartupUri`.
   If the project is Avalonia (`xmlns="https://github.com/avaloniaui"`) or WinUI (`Microsoft.UI.Xaml`), say so and stop using this skill.
2. **WPF is Windows-only**, even on modern .NET. The TFM is `net8.0-windows` (or similar), never plain `net8.0`. If the user needs cross-platform, raise it before writing code.
3. **Identify the runtime**: .NET Framework 4.x or modern .NET? This changes available C# features, NuGet packages, and csproj format. If migrating, read [references/migration.md](references/migration.md).

## Facts that prevent the most common errors

These correct widespread misconceptions. Trust them over instinct:

- **WPF has no compiled bindings.** `x:Bind` / `x:CompileBindings` are UWP/WinUI features. WPF only has reflection-based `{Binding}`. Never suggest `x:Bind` in WPF.
- **`TextBox.Text` binding updates on LostFocus by default.** Add `UpdateSourceTrigger=PropertyChanged` for live updates (e.g. search boxes, enabling Save buttons as the user types).
- **Binding failures are silent at runtime.** They only appear in the VS Output window / XAML Binding Failures window. Always tell the user how to surface them (see Debugging below).
- **Scalar property changes are auto-marshaled to the UI thread; collection changes are not.** `ObservableCollection<T>` modified from a background thread throws `NotSupportedException`. Either stay on the UI thread after `await` (default behavior — no `ConfigureAwait(false)` in ViewModels) or use `BindingOperations.EnableCollectionSynchronization`.
- **`[NotifyDataErrorInfo]` requires the ViewModel to inherit `ObservableValidator`**, not plain `ObservableObject`. Code using it on `ObservableObject` won't compile.
- **`d:DataContext` requires the `d` and `mc` namespaces** plus `mc:Ignorable="d"` or the XAML won't compile. Include them in every view you generate (full template in references/patterns.md).
- **With DI-driven startup, remove `StartupUri` from App.xaml**, or two windows open.
- **`Visibility` is a three-state enum** (`Visible`/`Collapsed`/`Hidden`); since .NET Framework 3.5 a `BooleanToVisibilityConverter` is built in — don't write a new one.
- **Virtualization silently turns off** when an `ItemsControl` sits inside a `StackPanel`/`ScrollViewer` that gives it infinite height, or when the panel isn't a `VirtualizingStackPanel`. Layout context matters more than the attached properties.

## Default architecture

Use **MVVM with CommunityToolkit.Mvvm** (`CommunityToolkit.Mvvm` NuGet, works on .NET Framework 4.6.2+ and modern .NET) and **Generic Host DI** unless the project already has another convention — match existing conventions in brownfield code.

```
MyApp/
├── App.xaml / App.xaml.cs      # Host setup, no StartupUri
├── Views/                      # XAML only; code-behind = InitializeComponent + view-only logic
├── ViewModels/                 # ObservableObject/ObservableValidator, [RelayCommand]
├── Models/                     # POCOs / domain types
├── Services/                   # Interfaces + implementations registered in DI
├── Converters/                 # IValueConverter implementations
├── Behaviors/                  # Microsoft.Xaml.Behaviors attached behaviors
└── Resources/                  # ResourceDictionaries (colors, styles, templates)
```

### Canonical ViewModel

```csharp
public partial class CustomersViewModel : ObservableObject
{
    private readonly ICustomerService _customers;

    public CustomersViewModel(ICustomerService customers) => _customers = customers;

    public ObservableCollection<Customer> Customers { get; } = [];

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SaveCommand))]
    public partial Customer? SelectedCustomer { get; set; }

    [ObservableProperty]
    public partial bool IsLoading { get; set; }

    [RelayCommand]
    private async Task LoadAsync(CancellationToken ct)
    {
        IsLoading = true;
        try
        {
            var items = await _customers.GetAllAsync(ct); // resumes on UI thread
            Customers.Clear();
            foreach (var c in items) Customers.Add(c);
        }
        finally { IsLoading = false; }
    }

    [RelayCommand(CanExecute = nameof(CanSave))]
    private Task SaveAsync() => _customers.SaveAsync(SelectedCustomer!);

    private bool CanSave() => SelectedCustomer is not null;
}
```

Notes that matter:
- `[ObservableProperty] public partial ...` requires MVVM Toolkit 8.4+ **and C# 13 / .NET 9 SDK**. On older setups, use the field form: `[ObservableProperty] private Customer? _selectedCustomer;`. Check the project before choosing.
- Mutating the existing `ObservableCollection` (instead of replacing it) preserves DataGrid scroll/selection and avoids re-rendering. Replace the collection only for full refreshes of large data sets — and then make the property `[ObservableProperty]` so the binding sees the swap.
- An async `[RelayCommand]` disables itself while running by default — often no manual `CanExecute` needed for "don't double-click" logic.
- Accepting a `CancellationToken` parameter plus `(IncludeCancelCommand = true)` generates a `LoadCancelCommand` for free.

### Canonical View

```xml
<Window x:Class="MyApp.Views.CustomersView"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
        xmlns:vm="clr-namespace:MyApp.ViewModels"
        mc:Ignorable="d"
        d:DataContext="{d:DesignInstance Type=vm:CustomersViewModel}"
        Title="Customers" Height="450" Width="800">
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>

        <ToolBar Grid.Row="0">
            <Button Content="Load" Command="{Binding LoadCommand}"/>
            <Button Content="Save" Command="{Binding SaveCommand}"/>
        </ToolBar>

        <DataGrid Grid.Row="1"
                  ItemsSource="{Binding Customers}"
                  SelectedItem="{Binding SelectedCustomer}"
                  IsReadOnly="True" AutoGenerateColumns="False">
            <DataGrid.Columns>
                <DataGridTextColumn Header="Name"  Binding="{Binding Name}"  Width="*"/>
                <DataGridTextColumn Header="Email" Binding="{Binding Email}" Width="2*"/>
            </DataGrid.Columns>
        </DataGrid>
    </Grid>
</Window>
```

### Wiring DataContext (the step everyone forgets)

```csharp
// Views/CustomersView.xaml.cs — constructor injection, one line of glue
public partial class CustomersView : Window
{
    public CustomersView(CustomersViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
    }
}
```

```csharp
// App.xaml.cs — Generic Host startup. App.xaml must NOT have StartupUri.
public partial class App : Application
{
    private readonly IHost _host = Host.CreateDefaultBuilder()
        .ConfigureServices(s =>
        {
            s.AddSingleton<ICustomerService, CustomerService>();
            s.AddSingleton<CustomersViewModel>();
            s.AddSingleton<CustomersView>();
        })
        .Build();

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _host.Start();
        _host.Services.GetRequiredService<CustomersView>().Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _host.Dispose();
        base.OnExit(e);
    }
}
```

Lifetimes: windows/VMs that exist once per app → singleton; per-dialog/per-tab VMs → transient, created via an injected `IServiceProvider` or factory.

## Threading rules

1. Prefer `async/await` end-to-end. After `await` in a ViewModel you're back on the UI thread (the `SynchronizationContext` does the marshaling) — so **never** write `ConfigureAwait(false)` in code that subsequently touches bound properties or collections.
2. Use `Task.Run` only to push CPU-bound work off the UI thread, and keep UI mutations outside the lambda:
   ```csharp
   var report = await Task.Run(() => BuildReport(data)); // CPU work off-thread
   ReportText = report;                                   // back on UI thread
   ```
3. Reach for `Dispatcher` only when receiving callbacks on unknown threads (timers, sockets, FileSystemWatcher, library events). Prefer `InvokeAsync` over `Invoke`.
4. Progress reporting from background work: `IProgress<T>`/`Progress<T>` (captures the UI context automatically).
5. Background-thread writes to a bound collection: `BindingOperations.EnableCollectionSynchronization(collection, lockObject)` — set up on the UI thread first.

## Debugging bindings (offer this proactively)

- VS **Output window** logs `System.Windows.Data Error: ...` for every failure; the **XAML Binding Failures** window (VS 2019 16.8+) aggregates them while debugging.
- Per-binding tracing: `xmlns:diag="clr-namespace:System.Diagnostics;assembly=System"` then `{Binding Name, diag:PresentationTraceSources.TraceLevel=High}`.
- Make failures loud in development: subscribe a `TraceListener` to `PresentationTraceSources.DataBindingSource` that throws/logs (pattern in references/anti-patterns.md).
- `{Binding}` path errors, wrong `DataContext`, and name typos are the #1 cause of "the UI just doesn't update" — check these before suspecting INPC.

## When the task involves...

| Task | Go to |
|---|---|
| Validation (`INotifyDataErrorInfo`, `ObservableValidator`, error templates), navigation between views, dialogs from VMs, messenger, design-time data, sorting/filtering with `CollectionViewSource`, event→command (`Microsoft.Xaml.Behaviors`), converters, attached behaviors | [references/patterns.md](references/patterns.md) |
| Memory leaks, binding mistakes, threading bugs, why-is-this-slow, async void, virtualization gotchas, resource (Static vs Dynamic) misuse | [references/anti-patterns.md](references/anti-patterns.md) |
| .NET Framework → modern .NET migration, SDK-style csproj, missing APIs, third-party control compatibility | [references/migration.md](references/migration.md) |
| Styling: implicit/keyed styles, `BasedOn`, ControlTemplates, DataTemplates + `DataTemplateSelector`, triggers, theming, resource organization | [references/styling.md](references/styling.md) |

Read the relevant file **before** writing code in that area; each contains corrections to common mistakes, not just examples.

## Testing ViewModels

MVVM Toolkit commands are testable without any WPF types:

```csharp
[Fact]
public async Task Load_PopulatesCustomers()
{
    var svc = Substitute.For<ICustomerService>();
    svc.GetAllAsync(Arg.Any<CancellationToken>())
       .Returns([new Customer { Name = "Test" }]);
    var vm = new CustomersViewModel(svc);

    await vm.LoadCommand.ExecuteAsync(null);

    Assert.Single(vm.Customers);
    Assert.False(vm.IsLoading);
}

[Fact]
public void Save_Disabled_WithoutSelection()
{
    var vm = new CustomersViewModel(Substitute.For<ICustomerService>());
    Assert.False(vm.SaveCommand.CanExecute(null));
}
```

If a test must touch WPF types (`DependencyObject`, controls), the test method needs an STA thread — use xUnit's `[StaFact]` from `Xunit.StaFact`. Plain `[Fact]` will throw `InvalidOperationException`.

## Validate before delivering

- [ ] Every generated XAML file compiles standalone: namespaces declared (`d`/`mc` if design-time attributes used), no `x:Bind`, no UWP/WinUI/Avalonia syntax
- [ ] `DataContext` is actually assigned somewhere (constructor injection, locator, or `DataTemplate`) — never assume it
- [ ] `StartupUri` removed if startup is code-driven
- [ ] Two-way input bindings on text fields have an explicit, intentional `UpdateSourceTrigger`
- [ ] No `ConfigureAwait(false)` in ViewModel code paths that touch bound state
- [ ] No business logic in code-behind; no `async void` except event handlers (with try/catch)
- [ ] Collection mutation happens on the UI thread or is synchronized
- [ ] Toolkit attribute form ([ObservableProperty] partial-property vs field) matches the project's SDK/toolkit version
